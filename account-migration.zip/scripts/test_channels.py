import copy, datetime, json, pathlib, unittest
from unittest.mock import patch
import collect_channels as c
from import_channel_capture import merge

ROOT=pathlib.Path(__file__).resolve().parents[1]
class ChannelSafety(unittest.TestCase):
    def setUp(self):
        self.data=json.loads((ROOT/'data/indian-builds/latest.json').read_text())
        self.data['accounts'][1]['metrics']['followers']['value']=0
        self.data['tracking']['excludedPostIds'].setdefault('tiktok',['excluded123'])
        self.now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    def batch(self,url='https://www.tiktok.com/@indian_builds'):
        return {'channelId':'indian-builds','platforms':{'tiktok':{'browserProfile':'lostastronaut.space','accountUrl':url,'observedAt':self.now,'profileMetrics':{},'posts':[]}}}
    def test_cooked_dev_cannot_be_imported_into_indian_builds(self):
        with self.assertRaises(ValueError):merge(self.data,self.batch('https://www.tiktok.com/@cooked_dev_'))
    def test_missing_metric_keeps_date_and_zero_is_preserved(self):
        before=copy.deepcopy(self.data);out=merge(self.data,self.batch())
        self.assertEqual(out['accounts'][1]['metrics']['followers'],before['accounts'][1]['metrics']['followers'])
        self.assertEqual(out['accounts'][1]['metrics']['followers']['value'],0)
        self.assertEqual(self.data,before)
    def test_legacy_and_wrong_authors_cannot_be_adopted(self):
        self.assertFalse(c.tracked_item(self.data,{'id':'999','author':{'uniqueId':'cooked_dev_'},'createTime':2000000000},'indian_builds'))
        legacy=self.data['tracking']['excludedPostIds']['tiktok'][0]
        self.assertFalse(c.tracked_item(self.data,{'id':legacy,'author':{'uniqueId':'indian_builds'},'createTime':2000000000},'indian_builds'))
        self.assertFalse(c.tracked_item(self.data,{'id':'999','author':{'uniqueId':'indian_builds'},'createTime':1},'indian_builds'))
    def test_matching_new_public_video_has_no_guessed_drive_or_instagram(self):
        batch=self.batch();batch['platforms']['tiktok']['posts']=[{'id':'999','url':'https://www.tiktok.com/@indian_builds/video/999','public':True,'caption':'A new build','metrics':{'views':0}}]
        out=merge(self.data,batch);v=out['videos'][-1]
        self.assertIsNone(v['assetUrl']);self.assertEqual(list(v['posts']),['tiktok'])
        self.assertEqual(v['posts']['tiktok']['metrics']['views']['value'],0)
    def test_wrong_profile_never_updates_counts(self):
        scope={'userInfo':{'user':{'uniqueId':'cooked_dev_'},'stats':{'followerCount':999}}}
        with patch.object(c.base,'request',return_value='ignored'),patch.object(c.base,'state',return_value={'webapp.user-detail':scope}):out=c.refresh(copy.deepcopy(self.data))
        self.assertEqual(out['accounts'][1]['metrics']['followers']['value'],0)
    def test_additional_channel_tracks_explicit_public_upload_count(self):
        scope={'userInfo':{'user':{'uniqueId':'indian_builds'},'stats':{'followerCount':0,'heartCount':25,'videoCount':0}},'itemList':[]}
        with patch.object(c.base,'request',return_value='ignored'),patch.object(c.base,'state',return_value={'webapp.user-detail':scope}):
            out=c.refresh(copy.deepcopy(self.data))
        self.assertEqual(out['accounts'][1]['metrics']['publishedCount']['value'],0)
        self.assertEqual(out['accounts'][1]['metrics']['publishedCount']['at'],c.base.NOW)
        self.assertEqual(out['discovery']['tiktok']['reportedPosts'],0)
        self.assertFalse(out['discovery']['tiktok']['complete'])
    def test_missing_upload_count_does_not_invent_zero(self):
        data=copy.deepcopy(self.data);data['accounts'][1]['metrics'].pop('publishedCount',None)
        scope={'userInfo':{'user':{'uniqueId':'indian_builds'},'stats':{'followerCount':0}},'itemList':[]}
        with patch.object(c.base,'request',return_value='ignored'),patch.object(c.base,'state',return_value={'webapp.user-detail':scope}):out=c.refresh(data)
        self.assertNotIn('publishedCount',out['accounts'][1]['metrics'])
        self.assertIsNone(out['discovery']['tiktok']['reportedPosts'])
    def test_registry_separates_sources(self):
        registry=json.loads((ROOT/'data/channels.json').read_text())['channels']
        self.assertEqual(len({r['id'] for r in registry}),len(registry))
        self.assertEqual(len({r['dataPath'] for r in registry}),len(registry))
        for channel in registry:
            data=json.loads((ROOT/channel['dataPath']).read_text())
            self.assertEqual(len({v['id'] for v in data['videos']}),len(data['videos']))
            if channel['id']=='indian-builds':
                self.assertEqual(data['channelId'],channel['id'])
                self.assertTrue(all(a.get('expectedHandle')=='indian_builds' for a in data['accounts'] if a['id'] in ['instagram','tiktok']))
                facebook=next(a for a in data['accounts'] if a['id']=='facebook')
                self.assertEqual(facebook['expectedPageId'],'61594164374065')
                self.assertEqual(facebook['url'],'https://www.facebook.com/profile.php?id=61594164374065')
                x=next(a for a in data['accounts'] if a['id']=='x')
                self.assertEqual(x['expectedHandle'],'IndiaanBuilds')
                self.assertEqual(x['url'],'https://x.com/IndiaanBuilds')
                yt=next(a for a in data['accounts'] if a['id']=='youtube')
                self.assertEqual(yt['expectedChannelId'],'UCgHxdk2zTRXwsoCrICSwiRg')
                excluded=data['tracking']['excludedPostIds']
                self.assertTrue(all(p['id'] not in excluded.get(platform,[]) for v in data['videos'] for platform,p in v['posts'].items()))
    def test_cooked_facebook_cannot_update_indian_builds(self):
        batch={'channelId':'indian-builds','platforms':{'facebook':{'browserProfile':'lostastronaut.space','accountUrl':'https://www.facebook.com/profile.php?id=61595564490107','observedAt':self.now,'profileMetrics':{'followers':999},'posts':[]}}}
        with self.assertRaises(ValueError):merge(self.data,batch)
    def test_facebook_accepts_only_matching_real_reel_id(self):
        batch={'channelId':'indian-builds','platforms':{'facebook':{'browserProfile':'lostastronaut.space','accountUrl':'https://www.facebook.com/profile.php?id=61594164374065','observedAt':self.now,'posts':[{'id':'123456789','url':'https://www.facebook.com/reel/123456789','public':True,'caption':'New build','metrics':{'views':0}}]}}}
        out=merge(self.data,batch)
        self.assertEqual(out['videos'][-1]['posts']['facebook']['metrics']['views']['value'],0)
        self.assertIsNone(out['videos'][-1]['assetUrl'])
        batch['platforms']['facebook']['posts'][0]['url']='https://www.facebook.com/reel/987654321'
        with self.assertRaises(ValueError):merge(self.data,batch)
    def test_youtube_requires_real_channel_identity(self):
        account={'expectedChannelId':'UCgHxdk2zTRXwsoCrICSwiRg','url':'https://www.youtube.com/channel/UCgHxdk2zTRXwsoCrICSwiRg','metrics':{}}
        initial={'metadata':{'channelMetadataRenderer':{'externalId':'UCNPkHyLJotjamsFxts47T2A'}},'contents':{'text':'999 subscribers'}}
        page='var ytInitialData = '+json.dumps(initial)+';'
        with self.assertRaises(ValueError):c.youtube_profile(account,page)
        self.assertEqual(account['metrics'],{})
        initial['metadata']['channelMetadataRenderer']['externalId']=account['expectedChannelId']
        initial['contents']['text']='0 subscribers';c.youtube_profile(account,'var ytInitialData = '+json.dumps(initial)+';')
        self.assertEqual(account['metrics']['followers']['value'],0)
    def test_youtube_adoption_requires_verified_owner(self):
        batch={'channelId':'indian-builds','platforms':{'youtube':{'browserProfile':'lostastronaut.space','accountUrl':'https://www.youtube.com/channel/UCgHxdk2zTRXwsoCrICSwiRg','observedAt':self.now,'posts':[{'id':'abcdefghijk','url':'https://www.youtube.com/shorts/abcdefghijk','public':True,'caption':'A build','ownerChannelId':'UCNPkHyLJotjamsFxts47T2A','metrics':{'views':0}}]}}}
        with self.assertRaises(ValueError):merge(self.data,batch)
        batch['platforms']['youtube']['posts'][0]['ownerChannelId']='UCgHxdk2zTRXwsoCrICSwiRg'
        out=merge(self.data,batch)
        self.assertEqual(out['videos'][-1]['posts']['youtube']['id'],'abcdefghijk')
        self.assertIsNone(out['videos'][-1]['assetUrl'])
    def test_x_rejects_cooked_dev_and_text_posts(self):
        batch={'channelId':'indian-builds','platforms':{'x':{'browserProfile':'lostastronaut.space','accountUrl':'https://x.com/IndiaanBuilds','observedAt':self.now,'posts':[{'id':'123456789','url':'https://x.com/Cooked_Deev/status/123456789','public':True,'isVideo':True,'caption':'A build','metrics':{'views':0}}]}}}
        with self.assertRaises(ValueError):merge(self.data,batch)
        batch['platforms']['x']['posts'][0]['url']='https://x.com/IndiaanBuilds/status/123456789'
        batch['platforms']['x']['posts'][0]['isVideo']=False
        with self.assertRaises(ValueError):merge(self.data,batch)
        batch['platforms']['x']['posts'][0]['isVideo']=True
        out=merge(self.data,batch)
        self.assertEqual(out['videos'][-1]['posts']['x']['metrics']['views']['value'],0)
        self.assertIsNone(out['videos'][-1]['assetUrl'])
if __name__=='__main__':unittest.main()
