"""Register one public channel without replacing concurrent channel snapshots."""
import hashlib, json, pathlib, shutil, sys
root=pathlib.Path.cwd().resolve();payload=pathlib.Path(__file__).resolve().parent/'payload'
sys.path.insert(0,str(root/'scripts'))
from snapshot_merge import validate

def read(path):return json.loads(path.read_text())
def write(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
channel={'id':'dumb-luck','name':'DUMB LUCK','dataPath':'data/dumb-luck/latest.json'}
site_channel={'id':'dumb-luck','name':'DUMB LUCK','logo':'assets/dumb-luck.png','dataUrl':'https://raw.githubusercontent.com/Jautis5/cooked-dev-stats/main/data/dumb-luck/latest.json','fallbackUrl':'data/dumb-luck.json'}
config_files=[('data/channels.json',channel),('site/data/channels.json',site_channel)]
configs=[]
for name,entry in config_files:
 path=root/name;d=read(path);prior=[c for c in d['channels'] if c['id']==entry['id']]
 if len(prior)>1 or (prior and any(prior[0].get(k)!=v for k,v in entry.items())):raise ValueError('Conflicting existing DUMB LUCK registry')
 if not prior:d['channels'].append(entry)
 configs.append((path,d))
feed=read(payload/'data/dumb-luck/latest.json');validate(feed)
if feed['channelId']!='dumb-luck' or feed['videos'] or any(a['metrics'] for a in feed['accounts']):raise ValueError('Initial feed has unexpected observations')
accounts={a['id']:a for a in feed['accounts']}
if set(accounts)!={'instagram','tiktok','youtube'} or accounts['instagram']['url']!='https://www.instagram.com/duumb_luck/' or accounts['tiktok']['url']!='https://www.tiktok.com/@duumbluck' or accounts['youtube']['expectedChannelId']!='UCB-BqPU60vRfUWGalt6fRtQ':raise ValueError('Unexpected channel identities')
sourcefiles={'scripts/import_browser_snapshot.py':'d7b2d77513e48c6dcb7007d78d9528c91402121a77550f42ecf1cebe30bbfd5f','scripts/test_browser_snapshot.py':'f5806b20e0f2ca269e76a10062ce258d93c5c3d88eec437108d84c486b35de2f'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for rel,expected in sourcefiles.items():
 dest=root/rel;new=payload/rel
 if sha(dest) not in (expected,sha(new)):raise ValueError('Concurrent source edit requires review: '+rel)
for rel in ['data/dumb-luck/latest.json','site/data/dumb-luck.json','site/assets/dumb-luck.png','scripts/test_dumb_luck.py']:
 dest=root/rel;src=payload/rel
 if dest.exists() and sha(dest)!=sha(src):raise ValueError('Existing data or asset requires review: '+rel)
for path,d in configs:write(path,d)
for rel in list(sourcefiles)+['data/dumb-luck/latest.json','site/data/dumb-luck.json','site/assets/dumb-luck.png','scripts/test_dumb_luck.py']:
 dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(payload/rel,dest)
collection=root/'COLLECTION.md';text=collection.read_text()
text=text.replace('There are three channels: Cooked Dev,\nIndian Builds and DontGetTraced.','There are four channels: Cooked Dev,\nIndian Builds, DontGetTraced and DUMB LUCK.')
text=text.replace('Read all three channels independently.','Read all registered channels independently.')
addition='\n## DUMB LUCK — 28 October 2026\n\nOwner-confirmed profiles: Instagram `duumb_luck`, TikTok `duumbluck`, YouTube channel `UCB-BqPU60vRfUWGalt6fRtQ`. Only measured public posts and metrics belong in the feed; scheduled uploads are not public posts. The public collector and browser bundle support this fourth channel. Missing measurements stay unknown, and per-metric timestamps are preserved.\n'
if '## DUMB LUCK — 28 October 2026' not in text:text+=addition
collection.write_text(text)
import collect
collect.exports(feed,root/'data/dumb-luck')
print('Registered DUMB LUCK without modifying existing channel feeds.')
